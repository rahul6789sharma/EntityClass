package com.example.switchyard.switchyard_helloWord;


import static java.lang.System.out;
import javax.xml.namespace.QName;

import org.switchyard.remote.RemoteInvoker;
import org.switchyard.remote.RemoteMessage;
import org.switchyard.remote.http.HttpInvoker;

public final class RemoteClient {

    private static final QName SERVICE = new QName(
            "urn:com.example.switchyard:switchyard-helloWord:1.0",
            "HelloWorldService");
    private static final String URL = "http://localhost:8080/switchyard-remote";

    public static void main(final String[] ignored) throws Exception {
       
        RemoteInvoker invoker = new HttpInvoker(URL);
        RemoteMessage message = new RemoteMessage();
        message.setService(SERVICE).setOperation("getMessage").setContent("test");

        RemoteMessage reply = invoker.invoke(message);
       
        if (reply.isFault()) {
            System.err.println("Oops ... something bad happened.  "
                    + reply.getContent());
        } else {
           
            out.println("==================================");
            out.println("SwitchYard Service? "  +  reply.getContent());
            out.println("==================================");
        }
    }
   
}