package com.example.switchyard.switchyard_helloWord;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.switchyard.component.test.mixins.cdi.CDIMixIn;
import org.switchyard.test.Invoker;
import org.switchyard.test.ServiceOperation;
import org.switchyard.test.SwitchYardRunner;
import org.switchyard.test.SwitchYardTestCaseConfig;
import org.switchyard.test.SwitchYardTestKit;

@RunWith(SwitchYardRunner.class)
@SwitchYardTestCaseConfig(config = SwitchYardTestCaseConfig.SWITCHYARD_XML, mixins = { CDIMixIn.class })
public class HelloWorldServiceTest {

	private SwitchYardTestKit testKit;
	private CDIMixIn cdiMixIn;
	@ServiceOperation("HelloWorldService")
	private Invoker service;

	@Test
	public void testGetMessage() throws Exception {
		
		String message = "Test Hello Message";
		String result = service.operation("getMessage").sendInOut(message)
				.getContent(String.class);
	
		
		System.out.println("Result : " + result);
	
		Assert.assertEquals("Hello by SwitchYard :Test Hello Message", result);
		//Assert.assertTrue("Implement me", false);
	}

}
