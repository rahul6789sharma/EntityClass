package com.example.switchyard.switchyard_helloWord;

import org.switchyard.component.bean.Service;

@Service(HelloWorldService.class)
public class HelloWorldServiceBean implements HelloWorldService {

	@Override
	public String getMessage(String msg) {
		String result = "Hello by SwitchYard :" + msg;
		return result;
	}
	
}
