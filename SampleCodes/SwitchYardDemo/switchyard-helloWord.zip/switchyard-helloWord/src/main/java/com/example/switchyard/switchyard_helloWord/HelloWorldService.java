package com.example.switchyard.switchyard_helloWord;

public interface HelloWorldService {

	public String getMessage(String msg);
	
}
